# Main file to run Kiko AI
