# Add your API keys and configuration here
GEMINI_API_KEY = ''
MONGO_URI = ''
VOICE_ID = ''
