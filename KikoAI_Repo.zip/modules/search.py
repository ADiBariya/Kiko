# Google search fallback using Gemini
