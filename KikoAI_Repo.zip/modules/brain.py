# Brain logic using Gemini
