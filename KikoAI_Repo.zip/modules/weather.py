# Weather fetch module
